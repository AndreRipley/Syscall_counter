#include "types.h"
#include "user.h"

int main(void) {
    int* hello;
    hello = NULL;
    printf(1, "This will not work %p\n", *hello);

    exit();
}
